import {Orientation} from "./orientation";

export interface Position {
  x: number
  y: number
  orientation: Orientation
}